rm test.sh
rm start.sh
rm jdk.sh
rm jdk1.sh
rm installer.sh
rm -r software
rm playit.sh
rm viaversion.sh
rm viabackword.sh
rm downloadplug.sh
rm home.sh
rm ram.sh
rm on.sh
rm on1.sh


./home.sh
rm -r mcserver