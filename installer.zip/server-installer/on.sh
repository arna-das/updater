java -Xmx111111111G -Xms111111111G -jar server.jar nogui
